"""Inner problem (gravity-free, steady, total stress -> u*^2 at the top) with the user's closure
functions (porosity, porosity_rate, integral_depth, mixing_length, drag, tau_d form). Scaled variables."""
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from load_user import mom

def inner_B(p,us,ztop_plus=2e5):
    nu,d=p.nu,p.d_p
    def rhs(z,y):
        v,sig=y; u=v*us; S=sig*us**2
        n=mom.porosity(z,p); dn=mom.porosity_rate(z,p)
        T=(S-nu*dn*u)/n
        l=mom.mixing_length(z,u,p)
        a=nu+p.lam*d/(1-p.eps_b)*(1-n)*u
        du=2*T/(a+np.sqrt(a*a+4*l*l*abs(T)))
        dS=nu*dn*du - n*mom.drag(n,u,p)/p.rho      # 0 = S' + e f/rho - nu eps' u'
        return [du/us, dS/us**2]
    zs=-1.5*d; nb=mom.porosity(zs,p)
    delta=nb*d/(np.sqrt(p.A_E)*(1-nb))            # Brinkman decay length with the e^2 Ergun form
    ztop=ztop_plus*nu/us
    def run(vd):
        return solve_ivp(rhs,(zs,ztop),[vd,nu*nb*vd/(delta*us)],method='LSODA',rtol=1e-10,atol=1e-13)
    def f(lg):
        with np.errstate(all='ignore'):
            s=run(np.exp(lg))
        sig=s.y[1,-1]
        if not s.success or not np.isfinite(sig) or s.t[-1]<ztop*0.999 or sig<=0: return 50.
        return np.log(sig)
    lo=-6.0
    while f(lo)>0: lo-=2
    hi=lo+2
    while f(hi)<0: lo,hi=hi,hi+2
    lg=brentq(f,lo,hi,xtol=1e-14)
    s=run(np.exp(lg))
    Zp=mom.integral_depth(ztop,p)*us/nu
    Bp=s.y[0,-1]-np.log(Zp)/p.kappa - 1/(2*p.kappa**3*Zp)
    return Bp,s,np.exp(f(lg))
