"""Import the user's module unchanged, with stubs for the FEniCSx/MPI imports."""
import sys, types, importlib.util
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from unittest import mock
for name in ['ufl','dolfinx','dolfinx.fem','dolfinx.mesh','dolfinx.fem.petsc','mpi4py']:
    sys.modules[name]=mock.MagicMock()
_use=plt.style.use; plt.style.use=lambda *a,**k: None
spec=importlib.util.spec_from_file_location('mom','/home/claude/user/momentum_ODE_solver.py')
mom=importlib.util.module_from_spec(spec); spec.loader.exec_module(mom)
plt.style.use=_use
