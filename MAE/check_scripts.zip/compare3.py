import numpy as np, warnings, pickle; warnings.filterwarnings('ignore')
from dataclasses import replace
from load_user import mom
import fem1d, compare as C
from inner_user import inner_B
kap=0.41
def setup(dplus,hd):
    p0=mom.Parameters(); d=p0.d_p; z1=hd*d; us0=dplus*p0.nu/d
    p=replace(p0,z1=z1,z0=-3*d,slope=us0**2/(p0.g*z1))
    zz=np.linspace(0,z1,200001); us=np.sqrt(p.g*p.slope*np.trapezoid(mom.porosity(zz,p),zz))
    return p,us
out=[]
for dp in (10,100,1000,10000):
  for hd in (100,1000,10000):
    p,us=setup(dp,hd); zn=C.mesh(p,us)
    Bin,s,_=inner_B(p,us)
    ui=np.interp(zn,s.t,s.y[0]*us)
    Z=mom.integral_depth(zn,p)
    hi=zn>s.t[-1]; ui[hi]=us*(np.log(Z[hi]*us/p.nu)/kap+Bin)
    comp=ui+np.where(zn>0,us*C.fs(np.clip(zn/p.z1,0,1))/kap,0.0)
    comp=np.maximum(comp,p.u_bed); comp[0]=p.u_bed
    u,it=fem1d.newton(p,zn,comp,maxit=300)
    m=zn>0
    Best=u[m]/us-(np.log(Z[m]*us/p.nu)+C.fs(zn[m]/p.z1))/kap
    Uf=np.trapezoid(u[m],zn[m])/p.z1; Up=us*((np.log(p.z1*us/p.nu)-1+C.If)/kap+Bin)
    dev=np.max(np.abs(u-comp))/us
    zd=zn[m]/p.d_p; pts=[x for x in (10,30,100,300,1000) if x<0.1*hd]
    print(f"d+={us*p.d_p/p.nu:.0f} h/d={hd} N={len(zn)} it={it} | B_inner={Bin:.3f} | full: "+' '.join(f"{x}:{np.interp(x,zd,Best):.3f}" for x in pts)+f" | U/u* full={Uf/us:.3f} pred={Up/us:.3f} | max|u_full-u_comp|/u*={dev:.3f}",flush=True)
    out.append(dict(dplus=us*p.d_p/p.nu,hd=hd,z=zn,u=u,comp=comp,us=us,Bin=Bin,Best=Best,zp=zn[m],Uf=Uf,Up=Up,d=p.d_p,nu=p.nu))
pickle.dump(out,open('cmp3.pkl','wb'))
