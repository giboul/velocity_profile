import numpy as np, warnings; warnings.filterwarnings('ignore')
from dataclasses import replace
from load_user import mom
import fem1d, compare as C
from inner_user import inner_B
kap=0.41
p0=mom.Parameters()
zz=np.linspace(0,p0.z1,20001); us_ref=np.sqrt(p0.g*p0.slope*np.trapezoid(mom.porosity(zz,p0),zz))
dp_ref=us_ref*p0.d_p/p0.nu
print(f"reference case: u*={us_ref:.4f} m/s, d+={dp_ref:.0f}, h/d (from z=0)={p0.z1/p0.d_p:.2f}")
for hd in (3.75,10,30,100,1000):
    d=p0.d_p; z1=hd*d
    p=replace(p0,z1=z1,slope=us_ref**2/(p0.g*z1))
    zz=np.linspace(0,z1,20001); us=np.sqrt(p.g*p.slope*np.trapezoid(mom.porosity(zz,p),zz))
    zn=C.mesh(p,us)
    Bin,s,_=inner_B(p,us)
    ui=np.interp(zn,s.t,s.y[0]*us); Z=mom.integral_depth(zn,p)
    hi=zn>s.t[-1]; ui[hi]=us*(np.log(Z[hi]*us/p.nu)/kap+Bin)
    comp=np.maximum(ui+np.where(zn>0,us*C.fs(np.clip(zn/p.z1,0,1))/kap,0.0),p.u_bed); comp[0]=p.u_bed
    try: u,it=fem1d.newton(p,zn,comp,maxit=300)
    except Exception as e: u,it=fem1d.newton(p,zn,fem1d.guess(p,zn),maxit=300)
    m=zn>0
    Uf=np.trapezoid(u[m],zn[m])/z1; Up=us*((np.log(z1*us/p.nu)-1+C.If)/kap+Bin)
    print(f"  h/d={hd:<6} d+={us*d/p.nu:.0f}  U/u*: full={Uf/us:.3f}  asymptotic={Up/us:.3f}  error={100*(Up-Uf)/Uf:+.2f}%",flush=True)
