"""Numpy port of solve_profile/solve: same weak form int[src v - tau v'] dz, P1, Dirichlet u_SSL at z0,
natural (zero-stress) BC at z1, laminar continuation, Newton + backtracking line search."""
import numpy as np
from dataclasses import replace
from scipy.linalg import solve_banded
from load_user import mom

def nodes(p):   # copy of refined_mesh's node placement
    wide=replace(p,d_p=2*p.d_p)
    z=np.linspace(p.z0,p.z1,50*p.n_cells+1)
    w=1+(p.refinement-1)*mom.porosity_rate(z,wide)/mom.porosity_rate(0,wide)
    W=np.cumsum(w)*(z[1]-z[0])
    return np.interp(np.linspace(W[0],W[-1],p.n_cells+1),W,z)

gx,gw=np.polynomial.legendre.leggauss(4)
def residual(u,zn,p):
    h=np.diff(zn); N=len(zn); R=np.zeros(N)
    du=np.diff(u)/h
    for x,w in zip(gx,gw):
        t=(x+1)/2; zq=zn[:-1]+t*h; uq=u[:-1]*(1-t)+u[1:]*t
        src=mom.source(zq,uq,du,p); tau=sum(mom.stresses(zq,uq,du,p))
        wq=w*h/2
        R[:-1]+=wq*(src*(1-t)+tau/h)   # phi_i=1-t, phi_i'=-1/h ; -tau*phi' = +tau/h
        R[1:] +=wq*(src*t   -tau/h)
    return R

def jac_banded(u,zn,p,R0):
    N=len(u); ab=np.zeros((3,N))
    for c in range(3):
        e=np.zeros(N); idx=np.arange(c,N,3); 
        dh=1e-7*np.maximum(1e-3,np.abs(u[idx])); e[idx]=dh
        dR=(residual(u+e,zn,p)-R0)
        for j,d in zip(idx,dh):
            for i in (j-1,j,j+1):
                if 0<=i<N: ab[1+i-j,j]=dR[i]/d
    return ab

def newton(p,zn,u,tol=1e-10,maxit=200):
    u=u.copy(); u[0]=p.u_bed
    scale=p.rho*p.g*p.slope*(p.z1-p.z0)
    for it in range(maxit):
        R=residual(u,zn,p); R[0]=0
        nr=np.linalg.norm(R)
        if nr<tol*scale: return u,it
        ab=jac_banded(u,zn,p,R)
        ab[:,0]=0; ab[1,0]=1; ab[0,1]=0   # Dirichlet row 0
        du=solve_banded((1,1),ab,-R)
        lam=1.0
        while lam>1e-6:
            un=u+lam*du; Rn=residual(un,zn,p); Rn[0]=0
            if np.all(np.isfinite(Rn)) and np.linalg.norm(Rn)<(1-1e-4*lam)*nr: break
            lam/=2
        if np.max(np.abs(un-u))<1e-10*np.max(np.abs(u)): 
            print(f'   [stol stop, |R|/scale={np.linalg.norm(Rn)/scale:.1e}]',end=''); return un,it
        u=un
    raise RuntimeError(f'no convergence, |R|/scale={nr/scale:.2e}')

def solve(p):
    zn=nodes(p)
    u0=np.full(len(zn),p.u_bed)
    ul,_=newton(replace(p,kappa=0.0,lam=0.0),zn,u0)
    u,it=newton(p,zn,ul)
    return zn,u

def guess(p,zn):
    us=np.sqrt(p.g*p.slope*(p.z1-p.z0)*0.9)
    Z=mom.integral_depth(zn,p)
    return p.u_bed+us/p.kappa*np.log(1+Z*us/(9*p.nu))

def solve_log(p,**kw):
    zn=nodes(p)
    u,it=newton(p,zn,guess(p,zn),**kw)
    return zn,u,it
