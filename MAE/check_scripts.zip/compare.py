import numpy as np, sys, warnings; warnings.filterwarnings('ignore')
from dataclasses import replace
from scipy.integrate import quad
from load_user import mom
import fem1d
from inner_user import inner_B
kap=0.41
def fs(s):  # outer correction for ell=kappa*Z without free-surface factor: u'=u*sqrt(1-s)/(kappa z)
    r=np.sqrt(1-s); return 2*r-2*np.log(1+r)-(2-2*np.log(2))
If=quad(fs,0,1)[0]
def mesh(p,us):
    d=p.d_p; D0=min(d/100,0.25*p.nu/us)
    core=np.arange(-2*d,3*d+D0/2,D0)
    up=[core[-1]];dz=D0
    while up[-1]<p.z1: dz*=1.03; up.append(up[-1]+dz)
    up=np.array(up[1:]); up=up[up<p.z1-dz/2]; up=np.append(up,p.z1)
    dn=[core[0]];dz=D0
    while dn[-1]>p.z0: dz*=1.03; dn.append(dn[-1]-dz)
    dn=np.array(dn[1:]); dn=dn[dn>p.z0+dz/2]; dn=np.append(dn,p.z0)
    return np.concatenate([dn[::-1],core,up])
def run(dplus,hd,refine=1.0):
    p0=mom.Parameters()
    d=p0.d_p; z1=hd*d
    us0=dplus*p0.nu/d
    p=replace(p0,z1=z1,z0=-3*d,slope=us0**2/(p0.g*z1))
    zz=np.linspace(0,z1,200001); us=np.sqrt(p.g*p.slope*np.trapezoid(mom.porosity(zz,p),zz))
    zn=mesh(p,us)
    if refine!=1.0:
        zn=np.interp(np.linspace(0,len(zn)-1,int(len(zn)*refine)),np.arange(len(zn)),zn)
    u0=fem1d.guess(p,zn); u,it=fem1d.newton(p,zn,u0,maxit=300)
    Z=mom.integral_depth(zn,p); m=zn>0
    Best=u[m]/us-(np.log(Z[m]*us/p.nu)+fs(zn[m]/z1))/kap
    Bin,_,_=inner_B(p,us)
    Ufull=np.trapezoid(u[m],zn[m])/z1
    Upred=us*((np.log(z1*us/p.nu)-1+If)/kap+Bin)
    return dict(dplus=us*d/p.nu,hd=hd,N=len(zn),it=it,Bin=Bin,z=zn[m],Best=Best,Ufull=Ufull,Upred=Upred,us=us)
if __name__=='__main__':
    out=[]
    for dplus in (10,100,1000):
        for hd in (100,1000,10000):
            r=run(dplus,hd); out.append(r)
            zd=r['z']/mom.Parameters().d_p
            pts=[x for x in (10,30,100,300,1000) if x<0.1*hd]
            vals=' '.join(f"{x}:{np.interp(x,zd,r['Best']):.3f}" for x in pts)
            print(f"d+={r['dplus']:.0f} h/d={hd} N={r['N']} it={r['it']} | B_inner={r['Bin']:.3f} | B from full model at Z/d -> {vals} | U_full/u*={r['Ufull']/r['us']:.3f} U_pred/u*={r['Upred']/r['us']:.3f}",flush=True)
    import pickle; pickle.dump(out,open('cmp.pkl','wb'))
